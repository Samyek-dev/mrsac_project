import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { type Region, type InsertRegion } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function useRegions() {
  const { toast } = useToast();

  const { 
    data: regions = [], 
    isLoading: isLoadingRegions, 
    error: regionsError 
  } = useQuery<Region[]>({
    queryKey: ['/api/regions'],
  });

  const selectedRegion = regions.find(region => region.isSelected);

  const createRegionMutation = useMutation({
    mutationFn: async (newRegion: InsertRegion) => {
      const response = await apiRequest('POST', '/api/regions', newRegion);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/regions'] });
      toast({
        title: "Region Created",
        description: "New region has been successfully added.",
        duration: 3000,
      });
    },
    onError: (error) => {
      toast({
        title: "Region Creation Failed",
        description: `Error: ${error.message}`,
        variant: "destructive",
        duration: 5000,
      });
    }
  });

  const selectRegionMutation = useMutation({
    mutationFn: async (regionId: number) => {
      const response = await apiRequest('PUT', `/api/regions/${regionId}/select`, null);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/regions'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to Select Region",
        description: `Error: ${error.message}`,
        variant: "destructive",
        duration: 5000,
      });
    }
  });

  const deleteRegionMutation = useMutation({
    mutationFn: async (regionId: number) => {
      await apiRequest('DELETE', `/api/regions/${regionId}`, null);
      return regionId;
    },
    onSuccess: (regionId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/regions'] });
      toast({
        title: "Region Deleted",
        description: "The region has been successfully removed.",
        duration: 3000,
      });
    },
    onError: (error) => {
      toast({
        title: "Region Deletion Failed",
        description: `Error: ${error.message}`,
        variant: "destructive",
        duration: 5000,
      });
    }
  });

  const updateRegionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertRegion> }) => {
      const response = await apiRequest('PATCH', `/api/regions/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/regions'] });
      toast({
        title: "Region Updated",
        description: "Region has been successfully updated.",
        duration: 3000,
      });
    },
    onError: (error) => {
      toast({
        title: "Region Update Failed",
        description: `Error: ${error.message}`,
        variant: "destructive",
        duration: 5000,
      });
    }
  });

  const searchRegions = (query: string): Region[] => {
    if (!query.trim()) return [];
    
    const lowerQuery = query.toLowerCase();
    return regions.filter(region => 
      region.name.toLowerCase().includes(lowerQuery)
    );
  };

  return {
    regions,
    isLoadingRegions,
    regionsError,
    selectedRegion,
    createRegion: createRegionMutation.mutate,
    isCreatingRegion: createRegionMutation.isPending,
    selectRegion: selectRegionMutation.mutate,
    isSelectingRegion: selectRegionMutation.isPending,
    deleteRegion: deleteRegionMutation.mutate,
    isDeletingRegion: deleteRegionMutation.isPending,
    updateRegion: updateRegionMutation.mutate,
    isUpdatingRegion: updateRegionMutation.isPending,
    searchRegions
  };
}
