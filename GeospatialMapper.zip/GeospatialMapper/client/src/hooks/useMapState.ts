import { useState, useCallback, useEffect } from 'react';
import { MapLayer } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

export type LatLng = {
  lat: number;
  lng: number;
};

export type ViewMode = 'default' | '3d' | 'street';

export type MeasurementTool = 'none' | 'distance' | 'area' | 'draw';

export type MapState = {
  center: LatLng;
  zoom: number;
  currentPosition: LatLng | null;
  layers: MapLayer[];
  viewMode: ViewMode;
  activeMeasurementTool: MeasurementTool;
  mapRotation: number;
  scale: number;
};

export default function useMapState() {
  const { toast } = useToast();
  
  const [mapState, setMapState] = useState<MapState>({
    center: { lat: 21.1458, lng: 79.0882 }, // Default to Nagpur
    zoom: 12,
    currentPosition: { lat: 21.1458, lng: 79.0882 },
    viewMode: 'default',
    activeMeasurementTool: 'none',
    mapRotation: 0,
    scale: 5, // Scale in kilometers
    layers: [
      {
        id: 'satellite',
        name: 'Satellite Imagery',
        visible: true,
        type: 'base',
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
      },
      {
        id: 'administrative',
        name: 'Administrative Boundaries',
        visible: true,
        type: 'overlay',
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
      },
      {
        id: 'terrain',
        name: 'Terrain',
        visible: false,
        type: 'overlay',
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
      },
      {
        id: 'roads',
        name: 'Roads & Transportation',
        visible: true,
        type: 'overlay',
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
      },
      {
        id: 'vegetation',
        name: 'Vegetation Cover',
        visible: false,
        type: 'overlay',
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
      }
    ]
  });

  const setCenter = useCallback((center: LatLng) => {
    setMapState(prev => ({ ...prev, center }));
  }, []);

  const setZoom = useCallback((zoom: number) => {
    setMapState(prev => ({ ...prev, zoom }));
  }, []);

  const setCurrentPosition = useCallback((position: LatLng) => {
    setMapState(prev => ({ ...prev, currentPosition: position }));
  }, []);

  const zoomIn = useCallback(() => {
    setMapState(prev => ({ ...prev, zoom: Math.min(prev.zoom + 1, 18) }));
  }, []);

  const zoomOut = useCallback(() => {
    setMapState(prev => ({ ...prev, zoom: Math.max(prev.zoom - 1, 3) }));
  }, []);

  const toggleLayer = useCallback((layerId: string) => {
    setMapState(prev => ({
      ...prev,
      layers: prev.layers.map(layer => 
        layer.id === layerId ? { ...layer, visible: !layer.visible } : layer
      )
    }));
  }, []);

  const setViewMode = useCallback((viewMode: ViewMode) => {
    setMapState(prev => ({ ...prev, viewMode }));
    
    // Add notification when changing view mode
    toast({
      title: "View Mode Changed",
      description: `Switched to ${viewMode === 'default' ? 'default' : viewMode === '3d' ? '3D' : 'street'} view mode.`,
      duration: 3000,
    });
  }, [toast]);

  const resetNorth = useCallback(() => {
    setMapState(prev => ({ ...prev, mapRotation: 0 }));
    
    toast({
      title: "Map Orientation Reset",
      description: "Map has been reoriented to North.",
      duration: 2000,
    });
  }, [toast]);

  const setMeasurementTool = useCallback((tool: MeasurementTool) => {
    setMapState(prev => ({ ...prev, activeMeasurementTool: tool }));
    
    if (tool !== 'none') {
      toast({
        title: "Measurement Tool Activated",
        description: `${tool.charAt(0).toUpperCase() + tool.slice(1)} tool is now active.`,
        duration: 3000,
      });
    }
  }, [toast]);

  return {
    mapState,
    setCenter,
    setZoom,
    setCurrentPosition,
    zoomIn,
    zoomOut,
    toggleLayer,
    setViewMode,
    resetNorth,
    setMeasurementTool,
  };
}
