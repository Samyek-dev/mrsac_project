import React from 'react';
import SearchWidget from './SearchWidget';
import LayersControl from './LayersControl';
import SavedRegions from './SavedRegions';
import RegionInfo from './RegionInfo';
import { MapLayer, Region } from '@shared/schema';

interface SidebarProps {
  isExpanded: boolean;
  toggleSidebar: () => void;
  layers: MapLayer[];
  toggleLayer: (layerId: string) => void;
  regions: Region[];
  selectedRegion: Region | undefined;
  onSelectRegion: (regionId: number) => void;
  onAddRegion: () => void;
  onSearch: (query: string) => Region[];
}

const Sidebar: React.FC<SidebarProps> = ({
  isExpanded,
  toggleSidebar,
  layers,
  toggleLayer,
  regions,
  selectedRegion,
  onSelectRegion,
  onAddRegion,
  onSearch
}) => {
  return (
    <div 
      id="sidebar" 
      className="bg-white h-full shadow-lg z-10 transition-all duration-300 flex flex-col"
      style={{ width: isExpanded ? '320px' : '0' }}
    >
      {/* Header */}
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center mr-3">
            <span className="material-icons text-white text-xl">public</span>
          </div>
          <h1 className="text-xl font-medium text-primary">GeoMapsPlus</h1>
        </div>
        <button 
          onClick={toggleSidebar}
          className="p-1 rounded-full hover:bg-gray-100 transition-colors duration-200"
        >
          <span className="material-icons text-text-secondary">menu_open</span>
        </button>
      </div>
      
      {/* Sidebar Content */}
      <div className="overflow-y-auto flex-grow">
        {/* Search Section */}
        <SearchWidget onSearch={onSearch} />
        
        {/* Layers Control */}
        <LayersControl layers={layers} onToggleLayer={toggleLayer} />
        
        {/* Saved Regions */}
        <SavedRegions 
          regions={regions} 
          selectedRegionId={selectedRegion?.id}
          onSelectRegion={onSelectRegion} 
          onAddRegion={onAddRegion} 
        />
        
        {/* Region Info (Only shown when a region is selected) */}
        {selectedRegion && (
          <RegionInfo 
            selectedRegion={selectedRegion} 
            onClose={() => onSelectRegion(0)} 
          />
        )}
      </div>
      
      {/* Sidebar Footer */}
      <div className="p-4 border-t border-gray-200 mt-auto">
        <div className="flex items-center justify-between">
          <div className="text-xs text-text-secondary">© 2023 GeoMapsPlus</div>
          <div className="flex space-x-2">
            <button className="p-1 rounded-full hover:bg-gray-100 transition-colors duration-200">
              <span className="material-icons text-text-secondary text-sm">help_outline</span>
            </button>
            <button className="p-1 rounded-full hover:bg-gray-100 transition-colors duration-200">
              <span className="material-icons text-text-secondary text-sm">settings</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
