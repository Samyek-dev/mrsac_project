import React from 'react';
import { Region } from '@shared/schema';
import { formatCoordinates } from '@/lib/utils';

interface RegionInfoProps {
  selectedRegion: Region;
  onClose: () => void;
}

const RegionInfo: React.FC<RegionInfoProps> = ({ selectedRegion, onClose }) => {
  // Dummy data for extra region details (normally would come from API)
  const regionExtras = {
    area: '217.56 km²',
    population: '2,405,665',
    elevation: '310 m'
  };

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-sm font-medium text-text-secondary uppercase">Region Information</h2>
        <button 
          onClick={onClose}
          className="text-text-secondary hover:text-text-primary"
        >
          <span className="material-icons text-sm">close</span>
        </button>
      </div>
      
      <div className="bg-surface-dark p-3 rounded-md">
        <h3 className="font-medium mb-2">{selectedRegion.name}</h3>
        
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="text-text-secondary">Coordinates:</div>
          <div className="font-mono">
            {formatCoordinates(selectedRegion.latitude, selectedRegion.longitude)}
          </div>
          
          <div className="text-text-secondary">Area:</div>
          <div>{regionExtras.area}</div>
          
          <div className="text-text-secondary">Population:</div>
          <div>{regionExtras.population}</div>
          
          <div className="text-text-secondary">Elevation:</div>
          <div>{regionExtras.elevation}</div>
        </div>
        
        <div className="mt-3">
          <button className="text-primary hover:text-primary-dark text-sm font-medium">
            View Full Details
          </button>
        </div>
      </div>
    </div>
  );
};

export default RegionInfo;
