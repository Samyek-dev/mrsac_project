import React from 'react';
import { MapLayer } from '@shared/schema';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

interface LayersControlProps {
  layers: MapLayer[];
  onToggleLayer: (layerId: string) => void;
}

const LayersControl: React.FC<LayersControlProps> = ({ layers, onToggleLayer }) => {
  return (
    <div className="p-4 border-b border-gray-200">
      <h2 className="text-sm font-medium text-text-secondary uppercase mb-3">Map Layers</h2>
      
      {layers.map((layer) => (
        <div key={layer.id} className="flex items-center justify-between mb-2">
          <Label className="flex items-center cursor-pointer">
            <Checkbox 
              checked={layer.visible}
              onCheckedChange={() => onToggleLayer(layer.id)}
              className="mr-2"
            />
            <span className="ml-2 text-sm">{layer.name}</span>
          </Label>
          <span className="material-icons text-text-secondary text-sm">
            {layer.visible ? 'visibility' : 'visibility_off'}
          </span>
        </div>
      ))}
    </div>
  );
};

export default LayersControl;
