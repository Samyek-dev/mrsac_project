import React from 'react';
import { Region } from '@shared/schema';
import { formatCoordinates } from '@/lib/utils';

interface SavedRegionsProps {
  regions: Region[];
  selectedRegionId?: number;
  onSelectRegion: (regionId: number) => void;
  onAddRegion: () => void;
}

const SavedRegions: React.FC<SavedRegionsProps> = ({ 
  regions, 
  selectedRegionId,
  onSelectRegion, 
  onAddRegion 
}) => {
  return (
    <div className="p-4 border-b border-gray-200">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-medium text-text-secondary uppercase">Saved Regions</h2>
        <button 
          onClick={onAddRegion}
          className="text-primary hover:text-primary-dark text-sm font-medium flex items-center"
        >
          <span className="material-icons text-sm mr-1">add_circle</span>
          Add New
        </button>
      </div>
      
      {regions.map((region) => (
        <div 
          key={region.id}
          className={`mb-2 p-2 ${region.id === selectedRegionId 
            ? 'bg-primary text-white' 
            : 'bg-gray-100 hover:bg-gray-200'} rounded-md cursor-pointer transition-colors duration-150`}
          onClick={() => onSelectRegion(region.id)}
        >
          <div className="font-medium">{region.name}</div>
          <div className={`text-xs ${region.id === selectedRegionId ? 'opacity-80' : 'text-text-secondary'}`}>
            {formatCoordinates(region.latitude, region.longitude)}
          </div>
        </div>
      ))}
      
      {regions.length === 0 && (
        <div className="text-center p-4 text-sm text-text-secondary">
          No saved regions. Click "Add New" to create one.
        </div>
      )}
    </div>
  );
};

export default SavedRegions;
