import React, { useState, useEffect } from 'react';
import { debounce } from '@/lib/utils';
import { Region } from '@shared/schema';

interface SearchWidgetProps {
  onSearch: (query: string) => Region[];
}

const SearchWidget: React.FC<SearchWidgetProps> = ({ onSearch }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Region[]>([]);
  const [isResultsVisible, setIsResultsVisible] = useState(false);

  const debouncedSearch = React.useCallback(
    debounce((query: string) => {
      const results = onSearch(query);
      setSearchResults(results);
      setIsResultsVisible(query.length > 0);
    }, 300),
    [onSearch]
  );

  useEffect(() => {
    debouncedSearch(searchQuery);
  }, [searchQuery, debouncedSearch]);

  return (
    <div className="p-4 border-b border-gray-200">
      <h2 className="text-sm font-medium text-text-secondary uppercase mb-3">Search Area</h2>
      <div className="relative">
        <input 
          type="text" 
          id="search-input" 
          className="w-full border border-gray-300 rounded-md py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
          placeholder="Search region or area..." 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <span className="material-icons absolute left-3 top-2 text-text-secondary">search</span>
      </div>
      <div className="mt-2">
        <div id="search-results" className={`text-sm ${!isResultsVisible || searchResults.length === 0 ? 'hidden' : ''}`}>
          {searchResults.map((result) => (
            <div 
              key={result.id}
              className="p-2 hover:bg-gray-100 cursor-pointer rounded transition-colors duration-150"
            >
              {result.name}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SearchWidget;
