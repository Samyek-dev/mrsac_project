import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { LatLng, MapState } from '@/hooks/useMapState';
import CompassWidget from './CompassWidget';
import CoordinateDisplay from './CoordinateDisplay';
import ScaleBar from './ScaleBar';
import ZoomControl from './ZoomControl';
import ViewControl from './ViewControl';
import MeasurementTools from './MeasurementTools';
import { Region } from '@shared/schema';

// Fix Leaflet icon issues
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

interface MapViewProps {
  mapState: MapState;
  setCurrentPosition: (latlng: LatLng) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  setViewMode: (mode: 'default' | '3d' | 'street') => void;
  resetNorth: () => void;
  setMeasurementTool: (tool: 'none' | 'distance' | 'area' | 'draw') => void;
  isSidebarExpanded: boolean;
  toggleSidebar: () => void;
  selectedRegion: Region | undefined;
}

const MapView: React.FC<MapViewProps> = ({
  mapState,
  setCurrentPosition,
  zoomIn,
  zoomOut,
  setViewMode,
  resetNorth,
  setMeasurementTool,
  isSidebarExpanded,
  toggleSidebar,
  selectedRegion
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  // Initialize map
  useEffect(() => {
    if (mapContainerRef.current && !mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [mapState.center.lat, mapState.center.lng],
        zoom: mapState.zoom,
        zoomControl: false // Disable default zoom control
      });

      // Add base tile layer (satellite)
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);

      // Add event listener for map moves to update current position
      map.on('mousemove', (e) => {
        setCurrentPosition({ lat: e.latlng.lat, lng: e.latlng.lng });
      });

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update map when center or zoom changes
  useEffect(() => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView(
        [mapState.center.lat, mapState.center.lng],
        mapState.zoom,
        { animate: true }
      );
    }
  }, [mapState.center, mapState.zoom]);

  // Update marker for selected region
  useEffect(() => {
    if (mapInstanceRef.current && selectedRegion) {
      // Clear existing markers
      mapInstanceRef.current.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
          mapInstanceRef.current?.removeLayer(layer);
        }
      });

      // Add marker for selected region
      const marker = L.marker(
        [selectedRegion.latitude, selectedRegion.longitude],
        { title: selectedRegion.name }
      );
      
      marker.addTo(mapInstanceRef.current);
      
      // Add popup
      marker.bindPopup(`
        <div class="font-sans p-1">
          <div class="font-medium">${selectedRegion.name}</div>
          <div class="text-xs">${selectedRegion.description || ''}</div>
        </div>
      `);

      // Center the map on the selected region
      mapInstanceRef.current.setView(
        [selectedRegion.latitude, selectedRegion.longitude],
        mapState.zoom,
        { animate: true }
      );
    }
  }, [selectedRegion]);

  return (
    <div className="flex-grow relative overflow-hidden">
      {/* Map Canvas */}
      <div 
        ref={mapContainerRef} 
        id="map-canvas" 
        className="w-full h-full"
      ></div>

      {/* Map Controls */}
      <div className="absolute top-4 right-4 flex flex-col space-y-3">
        <ZoomControl onZoomIn={zoomIn} onZoomOut={zoomOut} />
        <ViewControl 
          onViewChange={setViewMode} 
          onResetNorth={resetNorth} 
        />
        <MeasurementTools onSelectTool={setMeasurementTool} />
      </div>

      {/* Compass */}
      <CompassWidget rotation={mapState.mapRotation} />

      {/* Coordinate Display */}
      {mapState.currentPosition && (
        <CoordinateDisplay coordinates={mapState.currentPosition} />
      )}

      {/* Scale Bar */}
      <ScaleBar scale={mapState.scale} />

      {/* Collapsed Sidebar Button */}
      {!isSidebarExpanded && (
        <button 
          onClick={toggleSidebar}
          className="absolute top-4 left-4 bg-white p-2 rounded-md shadow-md hover:bg-gray-100 transition-colors duration-200"
        >
          <span className="material-icons">menu</span>
        </button>
      )}
    </div>
  );
};

export default MapView;
