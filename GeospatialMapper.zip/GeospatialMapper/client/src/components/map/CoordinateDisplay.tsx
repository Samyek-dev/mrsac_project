import React from 'react';
import { LatLng } from '@/hooks/useMapState';
import { formatCoordinates } from '@/lib/utils';

interface CoordinateDisplayProps {
  coordinates: LatLng;
}

const CoordinateDisplay: React.FC<CoordinateDisplayProps> = ({ coordinates }) => {
  return (
    <div className="absolute left-4 bottom-4 bg-white px-3 py-2 rounded-md shadow-md">
      <div className="text-xs text-text-secondary mb-1">Current Position</div>
      <div className="text-sm font-medium font-mono">
        {formatCoordinates(coordinates.lat, coordinates.lng)}
      </div>
    </div>
  );
};

export default CoordinateDisplay;
