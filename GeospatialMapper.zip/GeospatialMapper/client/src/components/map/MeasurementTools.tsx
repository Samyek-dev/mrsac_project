import React from 'react';

interface MeasurementToolsProps {
  onSelectTool: (tool: 'none' | 'distance' | 'area' | 'draw') => void;
}

const MeasurementTools: React.FC<MeasurementToolsProps> = ({ onSelectTool }) => {
  return (
    <div className="bg-white rounded-md shadow-md overflow-hidden">
      <button 
        className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 border-b border-gray-200" 
        title="Measure Distance"
        onClick={() => onSelectTool('distance')}
      >
        <span className="material-icons">straighten</span>
      </button>
      <button 
        className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 border-b border-gray-200" 
        title="Measure Area"
        onClick={() => onSelectTool('area')}
      >
        <span className="material-icons">square_foot</span>
      </button>
      <button 
        className="w-10 h-10 flex items-center justify-center hover:bg-gray-100" 
        title="Draw Shape"
        onClick={() => onSelectTool('draw')}
      >
        <span className="material-icons">create</span>
      </button>
    </div>
  );
};

export default MeasurementTools;
