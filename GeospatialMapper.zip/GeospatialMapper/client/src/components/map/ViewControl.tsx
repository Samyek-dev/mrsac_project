import React from 'react';

interface ViewControlProps {
  onViewChange: (mode: 'default' | '3d' | 'street') => void;
  onResetNorth: () => void;
}

const ViewControl: React.FC<ViewControlProps> = ({ onViewChange, onResetNorth }) => {
  return (
    <div className="bg-white rounded-md shadow-md overflow-hidden">
      <button 
        className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 border-b border-gray-200" 
        title="3D View"
        onClick={() => onViewChange('3d')}
      >
        <span className="material-icons">view_in_ar</span>
      </button>
      <button 
        className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 border-b border-gray-200" 
        title="Street View"
        onClick={() => onViewChange('street')}
      >
        <span className="material-icons">streetview</span>
      </button>
      <button 
        className="w-10 h-10 flex items-center justify-center hover:bg-gray-100" 
        title="Reset North"
        onClick={onResetNorth}
      >
        <span className="material-icons">navigation</span>
      </button>
    </div>
  );
};

export default ViewControl;
