import React from 'react';

interface ZoomControlProps {
  onZoomIn: () => void;
  onZoomOut: () => void;
}

const ZoomControl: React.FC<ZoomControlProps> = ({ onZoomIn, onZoomOut }) => {
  return (
    <div className="bg-white rounded-md shadow-md overflow-hidden">
      <button 
        className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 border-b border-gray-200" 
        title="Zoom In"
        onClick={onZoomIn}
      >
        <span className="material-icons">add</span>
      </button>
      <button 
        className="w-10 h-10 flex items-center justify-center hover:bg-gray-100" 
        title="Zoom Out"
        onClick={onZoomOut}
      >
        <span className="material-icons">remove</span>
      </button>
    </div>
  );
};

export default ZoomControl;
