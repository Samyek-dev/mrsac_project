import React from 'react';

interface ScaleBarProps {
  scale: number;
}

const ScaleBar: React.FC<ScaleBarProps> = ({ scale }) => {
  return (
    <div className="absolute right-4 bottom-4 bg-white px-3 py-2 rounded-md shadow-md flex items-center">
      <div className="flex flex-col">
        <div className="h-1 w-24 bg-primary mb-1"></div>
        <div className="text-xs text-text-secondary">{scale} kilometers</div>
      </div>
    </div>
  );
};

export default ScaleBar;
