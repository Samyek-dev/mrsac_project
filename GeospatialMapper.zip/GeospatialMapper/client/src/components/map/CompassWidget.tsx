import React from 'react';

interface CompassWidgetProps {
  rotation: number;
}

const CompassWidget: React.FC<CompassWidgetProps> = ({ rotation }) => {
  const compassStyle = {
    transform: `rotate(${rotation}deg)`
  };

  return (
    <div 
      className="absolute top-4 left-4 w-[70px] h-[70px] rounded-full bg-white bg-opacity-90 shadow-md flex items-center justify-center"
      title="North direction"
      style={compassStyle}
    >
      <div className="relative w-full h-full">
        {/* North pointer */}
        <div className="absolute top-1 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-l-transparent border-r-transparent border-b-[16px] border-b-[#EA4335]"></div>
        
        {/* North label */}
        <div className="absolute top-[22px] left-1/2 transform -translate-x-1/2 text-black font-medium">N</div>
        
        {/* East label */}
        <div className="absolute top-1/2 right-[9px] -translate-y-1/2 text-black font-medium">E</div>
        
        {/* South label */}
        <div className="absolute bottom-[9px] left-1/2 transform -translate-x-1/2 text-black font-medium">S</div>
        
        {/* West label */}
        <div className="absolute top-1/2 left-[9px] transform -translate-y-1/2 text-black font-medium">W</div>
      </div>
    </div>
  );
};

export default CompassWidget;
