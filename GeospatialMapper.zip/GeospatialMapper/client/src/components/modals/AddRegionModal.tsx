import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { InsertRegion } from '@shared/schema';

interface AddRegionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (regionData: InsertRegion) => void;
  isPending: boolean;
}

const AddRegionModal: React.FC<AddRegionModalProps> = ({ 
  isOpen, 
  onClose, 
  onSave,
  isPending
}) => {
  const [regionName, setRegionName] = useState('');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [description, setDescription] = useState('');
  const [drawBoundaries, setDrawBoundaries] = useState(false);

  const handleSave = () => {
    // Basic validation
    if (!regionName || !latitude || !longitude) {
      alert('Region name, latitude, and longitude are required.');
      return;
    }

    // Check if latitude and longitude are valid numbers
    const lat = parseFloat(latitude);
    const lng = parseFloat(longitude);
    
    if (isNaN(lat) || isNaN(lng)) {
      alert('Latitude and longitude must be valid numbers.');
      return;
    }

    // Create region data
    const regionData: InsertRegion = {
      name: regionName,
      latitude: lat,
      longitude: lng,
      description: description || null,
      boundaryData: null, // Would be set if drawing region
      isSelected: true,  // Automatically select new region
      userId: null
    };

    // Submit data
    onSave(regionData);
    
    // Reset form
    setRegionName('');
    setLatitude('');
    setLongitude('');
    setDescription('');
    setDrawBoundaries(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium">Add New Region</DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          <div className="mb-4">
            <Label className="block text-sm font-medium text-text-secondary mb-1">Region Name</Label>
            <Input 
              type="text" 
              placeholder="e.g. Nagpur, Maharashtra" 
              value={regionName}
              onChange={(e) => setRegionName(e.target.value)}
              className="w-full"
            />
          </div>
          
          <div className="mb-4">
            <Label className="block text-sm font-medium text-text-secondary mb-1">Coordinates</Label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Input 
                  type="text" 
                  placeholder="Latitude" 
                  value={latitude}
                  onChange={(e) => setLatitude(e.target.value)}
                  className="w-full"
                />
              </div>
              <div>
                <Input 
                  type="text" 
                  placeholder="Longitude" 
                  value={longitude}
                  onChange={(e) => setLongitude(e.target.value)}
                  className="w-full"
                />
              </div>
            </div>
          </div>
          
          <div className="mb-4">
            <Label className="block text-sm font-medium text-text-secondary mb-1">Description (Optional)</Label>
            <Textarea 
              placeholder="Brief description of this region" 
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="h-20 resize-none"
            />
          </div>
          
          <div>
            <Label className="flex items-center text-sm cursor-pointer">
              <Checkbox 
                id="draw-boundaries"
                checked={drawBoundaries}
                onCheckedChange={(checked) => setDrawBoundaries(!!checked)}
                className="mr-2"
              />
              <span className="ml-2">Draw region boundaries on map</span>
            </Label>
          </div>
        </div>
        
        <DialogFooter className="sm:justify-end">
          <Button
            variant="outline"
            onClick={onClose}
            className="mr-2"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleSave}
            disabled={isPending}
          >
            {isPending ? 'Saving...' : 'Save Region'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddRegionModal;
