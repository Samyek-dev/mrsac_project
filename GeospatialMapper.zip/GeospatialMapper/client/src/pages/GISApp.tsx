import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import MapView from '@/components/map/MapView';
import Sidebar from '@/components/sidebar/Sidebar';
import AddRegionModal from '@/components/modals/AddRegionModal';
import useMapState from '@/hooks/useMapState';
import useRegions from '@/hooks/useRegions';

const GISApp: React.FC = () => {
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(true);
  const [isAddRegionModalOpen, setIsAddRegionModalOpen] = useState(false);
  
  const { 
    mapState, 
    setCenter, 
    setZoom, 
    setCurrentPosition, 
    zoomIn, 
    zoomOut, 
    toggleLayer, 
    setViewMode, 
    resetNorth, 
    setMeasurementTool 
  } = useMapState();
  
  const {
    regions,
    isLoadingRegions,
    selectedRegion,
    createRegion,
    isCreatingRegion,
    selectRegion,
    searchRegions
  } = useRegions();

  const toggleSidebar = () => {
    setIsSidebarExpanded(!isSidebarExpanded);
  };

  const handleAddRegion = () => {
    setIsAddRegionModalOpen(true);
  };

  const handleSelectRegion = (regionId: number) => {
    if (regionId > 0) {
      selectRegion(regionId);
    }
  };

  return (
    <>
      <Helmet>
        <title>GeoMapsPlus - GIS and Remote Sensing for Nagpur, Maharashtra</title>
        <meta name="description" content="Interactive GIS and remote sensing web application focused on Nagpur, Maharashtra with mapping, search, and region management capabilities." />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1" />
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
      </Helmet>
      
      <div className="flex h-screen w-full overflow-hidden bg-gray-100 text-text-primary">
        {/* Sidebar */}
        <Sidebar 
          isExpanded={isSidebarExpanded}
          toggleSidebar={toggleSidebar}
          layers={mapState.layers}
          toggleLayer={toggleLayer}
          regions={regions}
          selectedRegion={selectedRegion}
          onSelectRegion={handleSelectRegion}
          onAddRegion={handleAddRegion}
          onSearch={searchRegions}
        />
        
        {/* Map View */}
        <MapView 
          mapState={mapState}
          setCurrentPosition={setCurrentPosition}
          zoomIn={zoomIn}
          zoomOut={zoomOut}
          setViewMode={setViewMode}
          resetNorth={resetNorth}
          setMeasurementTool={setMeasurementTool}
          isSidebarExpanded={isSidebarExpanded}
          toggleSidebar={toggleSidebar}
          selectedRegion={selectedRegion}
        />
        
        {/* Add Region Modal */}
        <AddRegionModal
          isOpen={isAddRegionModalOpen}
          onClose={() => setIsAddRegionModalOpen(false)}
          onSave={(regionData) => {
            createRegion(regionData);
            setIsAddRegionModalOpen(false);
          }}
          isPending={isCreatingRegion}
        />
      </div>
    </>
  );
};

export default GISApp;
