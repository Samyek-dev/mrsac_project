import { users, type User, type InsertUser, regions, type Region, type InsertRegion } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Region methods
  getAllRegions(): Promise<Region[]>;
  getRegion(id: number): Promise<Region | undefined>;
  createRegion(region: InsertRegion): Promise<Region>;
  updateRegion(id: number, region: Partial<InsertRegion>): Promise<Region | undefined>;
  deleteRegion(id: number): Promise<boolean>;
  selectRegion(id: number): Promise<Region | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private regions: Map<number, Region>;
  userCurrentId: number;
  regionCurrentId: number;

  constructor() {
    this.users = new Map();
    this.regions = new Map();
    this.userCurrentId = 1;
    this.regionCurrentId = 1;
    
    // Initialize with Nagpur region
    this.createRegion({
      name: "Nagpur, Maharashtra",
      latitude: 21.1458,
      longitude: 79.0882,
      description: "Nagpur is the third largest city and winter capital of the Indian state of Maharashtra.",
      boundaryData: null,
      isSelected: true,
      userId: null
    });
    
    // Add Mumbai Metropolitan
    this.createRegion({
      name: "Mumbai Metropolitan",
      latitude: 19.0760,
      longitude: 72.8777,
      description: "Mumbai, formerly known as Bombay, is the capital city of the Indian state of Maharashtra.",
      boundaryData: null,
      isSelected: false,
      userId: null
    });
    
    // Add Vidarbha Region
    this.createRegion({
      name: "Vidarbha Region",
      latitude: 20.9042,
      longitude: 77.9870,
      description: "Vidarbha is the eastern region of the Indian state of Maharashtra.",
      boundaryData: null,
      isSelected: false,
      userId: null
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Region implementation
  async getAllRegions(): Promise<Region[]> {
    return Array.from(this.regions.values());
  }
  
  async getRegion(id: number): Promise<Region | undefined> {
    return this.regions.get(id);
  }
  
  async createRegion(insertRegion: InsertRegion): Promise<Region> {
    const id = this.regionCurrentId++;
    const region: Region = { ...insertRegion, id };
    this.regions.set(id, region);
    return region;
  }
  
  async updateRegion(id: number, updates: Partial<InsertRegion>): Promise<Region | undefined> {
    const region = this.regions.get(id);
    if (!region) return undefined;
    
    const updatedRegion = { ...region, ...updates };
    this.regions.set(id, updatedRegion);
    return updatedRegion;
  }
  
  async deleteRegion(id: number): Promise<boolean> {
    return this.regions.delete(id);
  }
  
  async selectRegion(id: number): Promise<Region | undefined> {
    // Deselect all regions first
    for (const region of this.regions.values()) {
      if (region.isSelected) {
        this.regions.set(region.id, { ...region, isSelected: false });
      }
    }
    
    // Select the specified region
    const region = this.regions.get(id);
    if (!region) return undefined;
    
    const updatedRegion = { ...region, isSelected: true };
    this.regions.set(id, updatedRegion);
    return updatedRegion;
  }
}

export const storage = new MemStorage();
