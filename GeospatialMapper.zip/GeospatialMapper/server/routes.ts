import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertRegionSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API prefix for all routes
  const apiPrefix = "/api";
  
  // Get all regions
  app.get(`${apiPrefix}/regions`, async (req: Request, res: Response) => {
    try {
      const regions = await storage.getAllRegions();
      return res.status(200).json(regions);
    } catch (error) {
      console.error("Error fetching regions:", error);
      return res.status(500).json({ message: "Failed to fetch regions" });
    }
  });
  
  // Get specific region
  app.get(`${apiPrefix}/regions/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid region ID" });
      }
      
      const region = await storage.getRegion(id);
      if (!region) {
        return res.status(404).json({ message: "Region not found" });
      }
      
      return res.status(200).json(region);
    } catch (error) {
      console.error("Error fetching region:", error);
      return res.status(500).json({ message: "Failed to fetch region" });
    }
  });
  
  // Create new region
  app.post(`${apiPrefix}/regions`, async (req: Request, res: Response) => {
    try {
      const regionData = insertRegionSchema.parse(req.body);
      const newRegion = await storage.createRegion(regionData);
      return res.status(201).json(newRegion);
    } catch (error) {
      console.error("Error creating region:", error);
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      return res.status(500).json({ message: "Failed to create region" });
    }
  });
  
  // Update region
  app.patch(`${apiPrefix}/regions/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid region ID" });
      }
      
      // Partial validation since this is an update
      const regionData = insertRegionSchema.partial().parse(req.body);
      const updatedRegion = await storage.updateRegion(id, regionData);
      
      if (!updatedRegion) {
        return res.status(404).json({ message: "Region not found" });
      }
      
      return res.status(200).json(updatedRegion);
    } catch (error) {
      console.error("Error updating region:", error);
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      return res.status(500).json({ message: "Failed to update region" });
    }
  });
  
  // Delete region
  app.delete(`${apiPrefix}/regions/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid region ID" });
      }
      
      const success = await storage.deleteRegion(id);
      if (!success) {
        return res.status(404).json({ message: "Region not found" });
      }
      
      return res.status(204).send();
    } catch (error) {
      console.error("Error deleting region:", error);
      return res.status(500).json({ message: "Failed to delete region" });
    }
  });
  
  // Select region
  app.put(`${apiPrefix}/regions/:id/select`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid region ID" });
      }
      
      const selectedRegion = await storage.selectRegion(id);
      if (!selectedRegion) {
        return res.status(404).json({ message: "Region not found" });
      }
      
      return res.status(200).json(selectedRegion);
    } catch (error) {
      console.error("Error selecting region:", error);
      return res.status(500).json({ message: "Failed to select region" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
